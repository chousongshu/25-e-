#include "ti_msp_dl_config.h"
#include "MyPWM.h"
#include "sensor.h"

extern uint8_t track_ok;
extern uint8_t turn_state;
extern uint8_t N;
extern uint8_t yes;
void Setright_speed(
	int16_t speed)
{
	if(speed > 0 )
	{
		DL_GPIO_clearPins(Motor_AIN1_PORT, Motor_AIN1_PIN );
		DL_GPIO_setPins(Motor_AIN2_PORT,Motor_AIN2_PIN);
		DL_GPIO_setPins(Motor_BIN1_PORT, Motor_BIN1_PIN );
		DL_GPIO_clearPins(Motor_BIN2_PORT,Motor_BIN2_PIN);
		Set_duty(0,speed);
		Set_duty(1,speed);
	}
	else if(speed == 0)
	{
		DL_GPIO_setPins(Motor_AIN1_PORT, Motor_AIN1_PIN );
		DL_GPIO_setPins(Motor_AIN2_PORT,Motor_AIN2_PIN);
		DL_GPIO_setPins(Motor_BIN1_PORT, Motor_BIN1_PIN );
		DL_GPIO_setPins(Motor_BIN2_PORT,Motor_BIN2_PIN);
		Set_duty(0,speed);
		Set_duty(1,speed);		
	}

	else
	{
	    DL_GPIO_clearPins(Motor_AIN2_PORT, Motor_AIN2_PIN );
	    DL_GPIO_setPins(Motor_AIN1_PORT,Motor_AIN1_PIN);
		DL_GPIO_setPins(Motor_BIN2_PORT, Motor_BIN2_PIN );
	    DL_GPIO_clearPins(Motor_BIN1_PORT,Motor_BIN1_PIN);
	    Set_duty(0,-speed);
		Set_duty(1,-speed);
	}

	
}

void Setleft_speed(int16_t speed)
{
	if(speed > 0 )
	{
		DL_GPIO_clearPins(Motor_CIN1_PORT, Motor_CIN1_PIN );
		DL_GPIO_setPins(Motor_CIN2_PORT,Motor_CIN2_PIN);
		DL_GPIO_setPins(Motor_DIN1_PORT, Motor_DIN1_PIN );
		DL_GPIO_clearPins(Motor_DIN2_PORT,Motor_DIN2_PIN);
		Set_duty(2,speed);
		Set_duty(3,speed);
	}
	else if(speed == 0)
	{
		DL_GPIO_setPins(Motor_CIN1_PORT, Motor_CIN1_PIN );
		DL_GPIO_setPins(Motor_CIN2_PORT,Motor_CIN2_PIN);
		DL_GPIO_setPins(Motor_DIN1_PORT, Motor_DIN1_PIN );
		DL_GPIO_setPins(Motor_DIN2_PORT,Motor_DIN2_PIN);
		Set_duty(2,speed);
		Set_duty(3,speed);	
	}

	else
	{
	    DL_GPIO_clearPins(Motor_CIN1_PORT, Motor_CIN1_PIN );
	    DL_GPIO_setPins(Motor_CIN1_PORT,Motor_CIN1_PIN);
		DL_GPIO_clearPins(Motor_DIN1_PORT, Motor_DIN1_PIN );
	    DL_GPIO_setPins(Motor_DIN2_PORT,Motor_DIN2_PIN);
	    Set_duty(2,-speed);
		Set_duty(3,-speed);
	}

	
}

void car_stop(void)
{

	Setleft_speed(0);
	Setright_speed(0);
	turn_state = 0;
	N =0;
	yes = 0;
	
}