#ifndef _SENSOR_H
#define _SENSOR_H

extern uint8_t car_count;
extern int sensor_state[8];
void Read_Sensors(void);
int Calculate_Error(void);
void SensorPid_Control(void);
void Sensor_90(void);

#endif