#include "ti_msp_dl_config.h"
#include "sensor.h"
#include "motor.h"
#include "Delay.h"

// 新增转向控制相关定义
extern uint8_t turn_state;
uint8_t car_count = 0;
extern uint8_t track_ok;
extern uint8_t N;


int sensor_state[8] = {0};
const int sensor_weight[8] = {-15, -10, -6, -1, 1, 6, 10, 15};
#define Kp  20.0f    // 比例系数
#define Ki  0.15f     // 积分系数
#define Kd  5.0f     // 微分系数

// 基础速度和最大速度限制
#define BASE_SPEED      17     
#define MAX_SPEED       60    
#define MIN_SPEED       5   

float error = 0;         // 当前误差
float last_error = 0;    // 上一次误差
float integral = 0;      // 积分项
float derivative = 0;    // 微分项
float pid_output = 0;    // PID输出



void Read_Sensors(void) {
   
    sensor_state[0] = DL_GPIO_readPins(Sensors_PIN_0_PORT, Sensors_PIN_0_PIN);
    sensor_state[1] = DL_GPIO_readPins(Sensors_PIN_1_PORT, Sensors_PIN_1_PIN);
    sensor_state[2] = DL_GPIO_readPins(Sensors_PIN_2_PORT, Sensors_PIN_2_PIN);
    sensor_state[3] = DL_GPIO_readPins(Sensors_PIN_3_PORT, Sensors_PIN_3_PIN);
    sensor_state[4] = DL_GPIO_readPins(Sensors_PIN_4_PORT, Sensors_PIN_4_PIN);
    sensor_state[5] = DL_GPIO_readPins(Sensors_PIN_5_PORT, Sensors_PIN_5_PIN);
    sensor_state[6] = DL_GPIO_readPins(Sensors_PIN_6_PORT, Sensors_PIN_6_PIN);
    sensor_state[7] = DL_GPIO_readPins(Sensors_PIN_7_PORT, Sensors_PIN_7_PIN);
}

int Calculate_Error(void) {
    int sum = 0;
    int count = 0;
    int error = 0;
    
    // 计算检测到黑线的传感器权重和
    for (uint8_t i = 0; i < 8; i++) {
        if (sensor_state[i] != 0) {  // 检测到黑线
            sum += sensor_weight[i];
            count++;
        }
    }
    
 
    if (count > 0) {
        error = sum / count;
    } else {
        error = 0;
    }
	
    
    return error;
}

void SensorPid_Control(void) {
	
	int current_error = Calculate_Error();
    
    if (current_error != 0) {
        integral += current_error;
        
        if (integral > 60) integral = 60;
        if (integral < -60) integral = -60;
    } else {
        integral = 0; 
    }
    
    derivative = current_error - last_error;
    
    pid_output = Kp * current_error + Ki * integral + Kd * derivative;
    
    last_error = current_error;
	  
    int16_t left_speed = BASE_SPEED - pid_output;
    int16_t right_speed = BASE_SPEED + pid_output;
    
   
    if (left_speed > MAX_SPEED) left_speed = MAX_SPEED;
    if (left_speed < MIN_SPEED) left_speed = MIN_SPEED;
    if (right_speed > MAX_SPEED) right_speed = MAX_SPEED;
    if (right_speed < MIN_SPEED) right_speed = MIN_SPEED;
    

    Setleft_speed(left_speed);
	Setright_speed(right_speed);
	
}

void Sensor_90(void) {
   
        car_count ++;
        if(car_count == 4*N + 1){
            car_stop();
            N = 0;
            car_count = 0;
            return;
        }
        if (turn_state == 1) {
            // 左90°转向：左轮反转，右轮正转（或左慢右快）
            Setleft_speed(-15);  // 反转慢速
            Setright_speed(30);  // 正转快速
            delay_ms(1150);

        } else if (turn_state == 2) {
            // 右90°转向：右轮反转，左轮正转
            Setleft_speed(30);   // 正转快速
            Setright_speed(-10); // 反转慢速
            delay_ms(1150);
        }
        
            turn_state = 0;
            integral = 0;
            last_error = 0;

}
