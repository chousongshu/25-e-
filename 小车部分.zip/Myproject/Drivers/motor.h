#ifndef _MOTOR_H
#define _MOTOR_H

void Setright_speed(int16_t speed);
void Setleft_speed(int16_t speed);
void car_stop(void);

#endif