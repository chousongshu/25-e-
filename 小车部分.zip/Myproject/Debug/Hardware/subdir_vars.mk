################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/LED.c \
../Hardware/MyPWM.c \
../Hardware/MyUART.c \
../Hardware/key.c 

C_DEPS += \
./Hardware/LED.d \
./Hardware/MyPWM.d \
./Hardware/MyUART.d \
./Hardware/key.d 

OBJS += \
./Hardware/LED.o \
./Hardware/MyPWM.o \
./Hardware/MyUART.o \
./Hardware/key.o 

OBJS__QUOTED += \
"Hardware\LED.o" \
"Hardware\MyPWM.o" \
"Hardware\MyUART.o" \
"Hardware\key.o" 

C_DEPS__QUOTED += \
"Hardware\LED.d" \
"Hardware\MyPWM.d" \
"Hardware\MyUART.d" \
"Hardware\key.d" 

C_SRCS__QUOTED += \
"../Hardware/LED.c" \
"../Hardware/MyPWM.c" \
"../Hardware/MyUART.c" \
"../Hardware/key.c" 


