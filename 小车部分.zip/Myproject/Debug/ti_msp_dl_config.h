/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_0 */
#define PWM_0_INST                                                         TIMA0
#define PWM_0_INST_IRQHandler                                   TIMA0_IRQHandler
#define PWM_0_INST_INT_IRQN                                     (TIMA0_INT_IRQn)
#define PWM_0_INST_CLK_FREQ                                             32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_0_C0_PORT                                                 GPIOB
#define GPIO_PWM_0_C0_PIN                                          DL_GPIO_PIN_8
#define GPIO_PWM_0_C0_IOMUX                                      (IOMUX_PINCM25)
#define GPIO_PWM_0_C0_IOMUX_FUNC                     IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_PWM_0_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_0_C1_PORT                                                 GPIOB
#define GPIO_PWM_0_C1_PIN                                          DL_GPIO_PIN_9
#define GPIO_PWM_0_C1_IOMUX                                      (IOMUX_PINCM26)
#define GPIO_PWM_0_C1_IOMUX_FUNC                     IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_PWM_0_C1_IDX                                    DL_TIMER_CC_1_INDEX
/* GPIO defines for channel 2 */
#define GPIO_PWM_0_C2_PORT                                                 GPIOB
#define GPIO_PWM_0_C2_PIN                                          DL_GPIO_PIN_0
#define GPIO_PWM_0_C2_IOMUX                                      (IOMUX_PINCM12)
#define GPIO_PWM_0_C2_IOMUX_FUNC                     IOMUX_PINCM12_PF_TIMA0_CCP2
#define GPIO_PWM_0_C2_IDX                                    DL_TIMER_CC_2_INDEX
/* GPIO defines for channel 3 */
#define GPIO_PWM_0_C3_PORT                                                 GPIOA
#define GPIO_PWM_0_C3_PIN                                         DL_GPIO_PIN_17
#define GPIO_PWM_0_C3_IOMUX                                      (IOMUX_PINCM39)
#define GPIO_PWM_0_C3_IOMUX_FUNC                     IOMUX_PINCM39_PF_TIMA0_CCP3
#define GPIO_PWM_0_C3_IDX                                    DL_TIMER_CC_3_INDEX



/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                           32000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOB
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                         DL_GPIO_PIN_1
#define GPIO_UART_0_TX_PIN                                         DL_GPIO_PIN_0
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM13)
#define GPIO_UART_0_IOMUX_TX                                      (IOMUX_PINCM1)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM13_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                       IOMUX_PINCM1_PF_UART0_TX
#define UART_0_BAUD_RATE                                                  (9600)
#define UART_0_IBRD_32_MHZ_9600_BAUD                                       (208)
#define UART_0_FBRD_32_MHZ_9600_BAUD                                        (21)





/* Port definition for Pin Group LEDS */
#define LEDS_PORT                                                        (GPIOB)

/* Defines for LED1: GPIOB.2 with pinCMx 15 on package pin 50 */
#define LEDS_LED1_PIN                                            (DL_GPIO_PIN_2)
#define LEDS_LED1_IOMUX                                          (IOMUX_PINCM15)
/* Defines for LED2: GPIOB.3 with pinCMx 16 on package pin 51 */
#define LEDS_LED2_PIN                                            (DL_GPIO_PIN_3)
#define LEDS_LED2_IOMUX                                          (IOMUX_PINCM16)
/* Port definition for Pin Group GPIO_OLED */
#define GPIO_OLED_PORT                                                   (GPIOA)

/* Defines for PIN_SCL: GPIOA.23 with pinCMx 53 on package pin 24 */
#define GPIO_OLED_PIN_SCL_PIN                                   (DL_GPIO_PIN_23)
#define GPIO_OLED_PIN_SCL_IOMUX                                  (IOMUX_PINCM53)
/* Defines for PIN_SDA: GPIOA.2 with pinCMx 7 on package pin 42 */
#define GPIO_OLED_PIN_SDA_PIN                                    (DL_GPIO_PIN_2)
#define GPIO_OLED_PIN_SDA_IOMUX                                   (IOMUX_PINCM7)
/* Defines for AIN2: GPIOA.12 with pinCMx 34 on package pin 5 */
#define Motor_AIN2_PORT                                                  (GPIOA)
#define Motor_AIN2_PIN                                          (DL_GPIO_PIN_12)
#define Motor_AIN2_IOMUX                                         (IOMUX_PINCM34)
/* Defines for AIN1: GPIOA.13 with pinCMx 35 on package pin 6 */
#define Motor_AIN1_PORT                                                  (GPIOA)
#define Motor_AIN1_PIN                                          (DL_GPIO_PIN_13)
#define Motor_AIN1_IOMUX                                         (IOMUX_PINCM35)
/* Defines for BIN1: GPIOB.7 with pinCMx 24 on package pin 59 */
#define Motor_BIN1_PORT                                                  (GPIOB)
#define Motor_BIN1_PIN                                           (DL_GPIO_PIN_7)
#define Motor_BIN1_IOMUX                                         (IOMUX_PINCM24)
/* Defines for BIN2: GPIOB.6 with pinCMx 23 on package pin 58 */
#define Motor_BIN2_PORT                                                  (GPIOB)
#define Motor_BIN2_PIN                                           (DL_GPIO_PIN_6)
#define Motor_BIN2_IOMUX                                         (IOMUX_PINCM23)
/* Defines for CIN1: GPIOA.7 with pinCMx 14 on package pin 49 */
#define Motor_CIN1_PORT                                                  (GPIOA)
#define Motor_CIN1_PIN                                           (DL_GPIO_PIN_7)
#define Motor_CIN1_IOMUX                                         (IOMUX_PINCM14)
/* Defines for CIN2: GPIOB.10 with pinCMx 27 on package pin 62 */
#define Motor_CIN2_PORT                                                  (GPIOB)
#define Motor_CIN2_PIN                                          (DL_GPIO_PIN_10)
#define Motor_CIN2_IOMUX                                         (IOMUX_PINCM27)
/* Defines for DIN1: GPIOB.17 with pinCMx 43 on package pin 14 */
#define Motor_DIN1_PORT                                                  (GPIOB)
#define Motor_DIN1_PIN                                          (DL_GPIO_PIN_17)
#define Motor_DIN1_IOMUX                                         (IOMUX_PINCM43)
/* Defines for DIN2: GPIOB.18 with pinCMx 44 on package pin 15 */
#define Motor_DIN2_PORT                                                  (GPIOB)
#define Motor_DIN2_PIN                                          (DL_GPIO_PIN_18)
#define Motor_DIN2_IOMUX                                         (IOMUX_PINCM44)
/* Defines for PIN_0: GPIOA.28 with pinCMx 3 on package pin 35 */
#define Sensors_PIN_0_PORT                                               (GPIOA)
#define Sensors_PIN_0_PIN                                       (DL_GPIO_PIN_28)
#define Sensors_PIN_0_IOMUX                                       (IOMUX_PINCM3)
/* Defines for PIN_1: GPIOA.31 with pinCMx 6 on package pin 39 */
#define Sensors_PIN_1_PORT                                               (GPIOA)
#define Sensors_PIN_1_PIN                                       (DL_GPIO_PIN_31)
#define Sensors_PIN_1_IOMUX                                       (IOMUX_PINCM6)
/* Defines for PIN_2: GPIOB.4 with pinCMx 17 on package pin 52 */
#define Sensors_PIN_2_PORT                                               (GPIOB)
#define Sensors_PIN_2_PIN                                        (DL_GPIO_PIN_4)
#define Sensors_PIN_2_IOMUX                                      (IOMUX_PINCM17)
/* Defines for PIN_3: GPIOB.5 with pinCMx 18 on package pin 53 */
#define Sensors_PIN_3_PORT                                               (GPIOB)
#define Sensors_PIN_3_PIN                                        (DL_GPIO_PIN_5)
#define Sensors_PIN_3_IOMUX                                      (IOMUX_PINCM18)
/* Defines for PIN_4: GPIOA.10 with pinCMx 21 on package pin 56 */
#define Sensors_PIN_4_PORT                                               (GPIOA)
#define Sensors_PIN_4_PIN                                       (DL_GPIO_PIN_10)
#define Sensors_PIN_4_IOMUX                                      (IOMUX_PINCM21)
/* Defines for PIN_5: GPIOA.11 with pinCMx 22 on package pin 57 */
#define Sensors_PIN_5_PORT                                               (GPIOA)
#define Sensors_PIN_5_PIN                                       (DL_GPIO_PIN_11)
#define Sensors_PIN_5_IOMUX                                      (IOMUX_PINCM22)
/* Defines for PIN_6: GPIOB.12 with pinCMx 29 on package pin 64 */
#define Sensors_PIN_6_PORT                                               (GPIOB)
#define Sensors_PIN_6_PIN                                       (DL_GPIO_PIN_12)
#define Sensors_PIN_6_IOMUX                                      (IOMUX_PINCM29)
/* Defines for PIN_7: GPIOB.13 with pinCMx 30 on package pin 1 */
#define Sensors_PIN_7_PORT                                               (GPIOB)
#define Sensors_PIN_7_PIN                                       (DL_GPIO_PIN_13)
#define Sensors_PIN_7_IOMUX                                      (IOMUX_PINCM30)
/* Defines for key1: GPIOB.21 with pinCMx 49 on package pin 20 */
#define Keys_key1_PORT                                                   (GPIOB)
#define Keys_key1_PIN                                           (DL_GPIO_PIN_21)
#define Keys_key1_IOMUX                                          (IOMUX_PINCM49)
/* Defines for key2: GPIOA.26 with pinCMx 59 on package pin 30 */
#define Keys_key2_PORT                                                   (GPIOA)
#define Keys_key2_PIN                                           (DL_GPIO_PIN_26)
#define Keys_key2_IOMUX                                          (IOMUX_PINCM59)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_0_init(void);
void SYSCFG_DL_UART_0_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
