################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/motor.c \
../Drivers/sensor.c 

C_DEPS += \
./Drivers/motor.d \
./Drivers/sensor.d 

OBJS += \
./Drivers/motor.o \
./Drivers/sensor.o 

OBJS__QUOTED += \
"Drivers\motor.o" \
"Drivers\sensor.o" 

C_DEPS__QUOTED += \
"Drivers\motor.d" \
"Drivers\sensor.d" 

C_SRCS__QUOTED += \
"../Drivers/motor.c" \
"../Drivers/sensor.c" 


