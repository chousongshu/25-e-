# FIXED

Drivers/sensor.o: ../Drivers/sensor.c \
 ti_msp_dl_config.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/msp.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/DeviceFamily.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/m0p/mspm0g350x.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_adc12.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_aes.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_comp.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_crc.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_dac12.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_dma.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_flashctl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_gpio.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_gptimer.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_i2c.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_iomux.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_mathacl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_mcan.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_oa.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_rtc.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_spi.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_trng.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_uart.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_vref.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_wuc.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_wwdt.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/driverlib.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_adc12.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_common.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_factoryregion.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_core.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_aes.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_aesadv.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_comp.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_crc.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_crcp.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_dac12.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_dma.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_flashctl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_sysctl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_gpamp.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_gpio.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_i2c.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_iwdt.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_lfss.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_keystorectl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_lcd.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_mathacl.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_mcan.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_opa.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc_common.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc_a.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc_b.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_scratchpad.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_spi.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_tamperio.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_timera.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_timer.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_timerg.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_trng.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_uart_extend.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_uart.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_uart_main.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_vref.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_wwdt.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_interrupt.h \
 E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_systick.h \
 ../Drivers/sensor.h ../Drivers/motor.h \
 C:/Users/chousongshu/workspace_ccstheia/Myproject/System/Delay.h
ti_msp_dl_config.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/msp.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/DeviceFamily.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/m0p/mspm0g350x.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_adc12.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_aes.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_comp.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_crc.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_dac12.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_dma.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_flashctl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_gpio.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_gptimer.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_i2c.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_iomux.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_mathacl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_mcan.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_oa.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_rtc.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_spi.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_trng.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_uart.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_vref.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_wuc.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/hw_wwdt.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/driverlib.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_adc12.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_common.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_factoryregion.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_core.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_aes.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_aesadv.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_comp.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_crc.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_crcp.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_dac12.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_dma.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_flashctl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_sysctl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_gpamp.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_gpio.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_i2c.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_iwdt.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_lfss.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_keystorectl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_lcd.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_mathacl.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_mcan.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_opa.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc_common.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc_a.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_rtc_b.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_scratchpad.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_spi.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_tamperio.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_timera.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_timer.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_timerg.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_trng.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_uart_extend.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_uart.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_uart_main.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_vref.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/dl_wwdt.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_interrupt.h:
E:/mspm0/mspm0_sdk_2_04_00_06/source/ti/driverlib/m0p/dl_systick.h:
../Drivers/sensor.h:
../Drivers/motor.h:
C:/Users/chousongshu/workspace_ccstheia/Myproject/System/Delay.h:
