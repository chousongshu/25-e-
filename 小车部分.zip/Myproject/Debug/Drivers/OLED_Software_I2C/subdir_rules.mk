################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Drivers/OLED_Software_I2C/%.o: ../Drivers/OLED_Software_I2C/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: Arm Compiler'
	"E:/ti/ccs/tools/compiler/ti-cgt-armllvm_4.0.2.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/LSM6DSV16X" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/VL53L0X" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/WIT" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/BNO08X_UART_RVC" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/Ultrasonic_GPIO" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/Ultrasonic_Capture" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/OLED_Hardware_I2C" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/OLED_Hardware_SPI" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/OLED_Software_I2C" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/OLED_Software_SPI" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/MPU6050" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Debug" -I"E:/mspm0/mspm0_sdk_2_04_00_06/source/third_party/CMSIS/Core/Include" -I"E:/mspm0/mspm0_sdk_2_04_00_06/source" -I"C:/Users/chousongshu/workspace_ccstheia/mpu6050-oled-software-i2c/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"Drivers/OLED_Software_I2C/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


