#include "ti_msp_dl_config.h"

void delay_ms(uint32_t ms){
    while(ms--){
        delay_cycles(CPUCLK_FREQ/1000);
    }
}

void delay_us(uint32_t us){
    while(us--){
        delay_cycles(80);
    }
}

void delay_s(uint32_t s){
    while(s--){
        delay_ms(1000);
    }
}