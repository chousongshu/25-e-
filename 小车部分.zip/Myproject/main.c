#include "ti_msp_dl_config.h"
#include "Delay.h"
#include "oled_software_i2c.h"
#include "LED.h"
#include "MyPWM.h"
#include "MyUART.h"
#include "stdio.h"
#include "motor.h"
#include "sensor.h"
#include "key.h"

uint8_t track_ok = 1;
uint8_t turn_state = 0;
uint8_t N = 0;
uint8_t yes = 0;
uint8_t key1num;
uint8_t key2num;

int main(void)
{
    SYSCFG_DL_init();
    

    OLED_Init();
    // NVIC_EnableIRQ(UART_0_INST_INT_IRQN); //使能串口中断
    // NVIC_EnableIRQ(ADC1_INST_INT_IRQN);//使能ADC中断
    DL_TimerA_startCounter(PWM_0_INST); //使能定时器A
    while (1) 
    {
        key1num = Key1_GetNum();
        key2num = Key2_GetNum();
        if(key1num != 0){
            N++;
            if(N>5){
                N =0;
            }
        }
        if(key2num != 0){
            yes = 1;
        }

        if(N>0 && yes==1){
            Read_Sensors();
            if((sensor_state[0] != 0)&&(sensor_state[1] != 0)&&(sensor_state[2] != 0)&&(sensor_state[3] != 0)&&(sensor_state[4] == 0)&&(sensor_state[5] == 0)&&(sensor_state[6] == 0)&&(sensor_state[7] == 0)
            ||(sensor_state[0] != 0)&&(sensor_state[1] != 0)&&(sensor_state[2] != 0)&&(sensor_state[3] != 0)&&(sensor_state[4] != 0)&&(sensor_state[5] == 0)&&(sensor_state[6] == 0)&&(sensor_state[7] == 0))
            {
                turn_state = 2;
            }
            else if((sensor_state[0] == 0)&&(sensor_state[1] == 0)&&(sensor_state[2] == 0)&&(sensor_state[3] == 0)&&(sensor_state[4] != 0)&&(sensor_state[5] != 0)&&(sensor_state[6] != 0)&&(sensor_state[7] != 0)
            ||(sensor_state[0] == 0)&&(sensor_state[1] == 0)&&(sensor_state[2] == 0)&&(sensor_state[3] != 0)&&(sensor_state[4] != 0)&&(sensor_state[5] != 0)&&(sensor_state[6] != 0)&&(sensor_state[7] != 0))
            {
                turn_state = 1;
            }
            else {
                turn_state = 0;
            }

            if(turn_state != 0 && N>0){
                Sensor_90();
            }

            if(track_ok == 1 && N>0)
            {
                SensorPid_Control();
            }
        }
    }
}

// int fputc(int c, FILE* stream)
// {
// 	DL_UART_Main_transmitDataBlocking(UART_0_INST, c);
//     return c;
// }

// int fputs(const char* restrict s, FILE* restrict stream)
// {
//     uint16_t i, len;
//     len = strlen(s);
//     for(i=0; i<len; i++)
//     {
//         DL_UART_Main_transmitDataBlocking(UART_0_INST, s[i]);
//     }
//     return len;
// }

// int puts(const char *_ptr)
// {
// int count = fputs(_ptr, stdout);
// count += fputs("\n", stdout);
// return count;
// }