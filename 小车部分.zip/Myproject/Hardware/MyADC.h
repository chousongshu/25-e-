#ifndef _MyADC_H
#define _MyADC_H

void adc_getValue(void);
extern uint16_t AdcResult[4];
extern bool gCheckADC;
#endif