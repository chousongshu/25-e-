#include "ti_msp_dl_config.h"

void LED1_OFF(void){
    DL_GPIO_clearPins(LEDS_PORT, LEDS_LED1_PIN);
}

void LED2_OFF(void){
    DL_GPIO_clearPins(LEDS_PORT, LEDS_LED2_PIN);
}

void LED1_ON(void){
    DL_GPIO_setPins(LEDS_PORT, LEDS_LED1_PIN);
}

void LED2_ON(void){
    DL_GPIO_setPins(LEDS_PORT, LEDS_LED2_PIN);
}

