#ifndef _MyPWM_H
#define _MyPWM_H

void Set_duty(uint8_t channel,float duty);
void Set_freq(uint32_t freq);
extern uint32_t period;

#endif