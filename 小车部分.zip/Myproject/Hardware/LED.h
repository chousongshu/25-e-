#ifndef _LED_H
#define _LED_H

void LED1_ON(void);
void LED2_ON(void);
void LED1_OFF(void);
void LED2_OFF(void);

#endif