#include "ti_msp_dl_config.h"
#include "Delay.h"

uint8_t Key1_GetNum(void)
{
	uint8_t KeyNum = 0;
	if (DL_GPIO_readPins(Keys_key1_PORT, Keys_key1_PIN) == 0)
	{
		delay_ms(50);
		while (DL_GPIO_readPins(Keys_key1_PORT, Keys_key1_PIN) == 0);
		delay_ms(50);
		KeyNum = 1;
	}

    return KeyNum;
}

uint8_t Key2_GetNum(void)
{
	uint8_t KeyNum = 0;
	if (DL_GPIO_readPins(Keys_key2_PORT, Keys_key2_PIN) == 0)
	{
		delay_ms(50);
		while (DL_GPIO_readPins(Keys_key2_PORT, Keys_key2_PIN) == 0);
		delay_ms(50);
		KeyNum = 1;
	}

    return KeyNum;
}