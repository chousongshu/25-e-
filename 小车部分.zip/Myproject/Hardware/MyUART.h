#ifndef _MyUART_H
#define _MyUART_H

void uart0_send_char(char ch);
void uart0_send_string(char* str);


#endif