#include "ti_msp_dl_config.h"


bool gCheckADC = false;
uint16_t AdcResult[4];


void adc_getValue(void)
{
      //软件触发ADC开始转换 
        DL_ADC12_startConversion(ADC1_INST);
        //如果当前状态为正在转换中则等待转换结束 
        while (false == gCheckADC) {}
        //获取数据 
        AdcResult[0] = DL_ADC12_getMemResult(ADC1_INST, ADC1_ADCMEM_0);
        AdcResult[1] = DL_ADC12_getMemResult(ADC1_INST, ADC1_ADCMEM_1);
        AdcResult[2] = DL_ADC12_getMemResult(ADC1_INST, ADC1_ADCMEM_2);
        AdcResult[3] = DL_ADC12_getMemResult(ADC1_INST, ADC1_ADCMEM_3);

        //清除标志位
        gCheckADC = false;

}

void ADC1_INST_IRQHandler(void)
{
    //查询并清除ADC中断 
    switch (DL_ADC12_getPendingInterrupt(ADC1_INST))
    {
        //检查是否完成数据采集 
        case DL_ADC12_IIDX_MEM3_RESULT_LOADED:
            gCheckADC = true;//将标志位置1 
            break;
        default:
            break;
    }
}