#include "ti_msp_dl_config.h"
uint32_t period = 32000;


void Set_duty(uint8_t channel,float duty){
    uint32_t comparevalue = period - duty*period/100.f;

    switch(channel){

        case 0:
        DL_TimerA_setCaptureCompareValue(PWM_0_INST,comparevalue,DL_TIMER_CC_0_INDEX);
        break;

        case 1:
        DL_TimerA_setCaptureCompareValue(PWM_0_INST,comparevalue,DL_TIMER_CC_1_INDEX);
        break;

        case 2:
        DL_TimerA_setCaptureCompareValue(PWM_0_INST,comparevalue,DL_TIMER_CC_2_INDEX);
        break;

        case 3:
        DL_TimerA_setCaptureCompareValue(PWM_0_INST,comparevalue,DL_TIMER_CC_3_INDEX);
    }
}

void Set_freq(uint32_t freq){
    period = 32000000/freq;
    DL_Timer_setLoadValue(PWM_0_INST, period);
}