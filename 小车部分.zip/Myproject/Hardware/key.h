#ifndef _KEY_H
#define _KEY_H

uint8_t Key1_GetNum(void);
uint8_t Key2_GetNum(void);


#endif