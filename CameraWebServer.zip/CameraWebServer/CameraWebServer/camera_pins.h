
#define PWDN_GPIO_NUM  -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM  0
#define SIOD_GPIO_NUM  11
#define SIOC_GPIO_NUM  10

#define Y2_GPIO_NUM 5 //DO
#define Y3_GPIO_NUM 6 //D1
#define Y4_GPIO_NUM 7 //D2
#define Y5_GPIO_NUM 15 //D3
#define Y6_GPIO_NUM 16 //D4
#define Y7_GPIO_NUM 17 //D5
#define Y8_GPIO_NUM 18 //D6
#define Y9_GPIO_NUM 8 //D7

#define VSYNC_GPIO_NUM 9
#define HREF_GPIO_NUM  40
#define PCLK_GPIO_NUM  21
